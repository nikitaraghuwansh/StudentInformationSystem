package com.dto;

public class StudentInformation {
	

	public StudentInformation(String studentName, String studentEmaiId, String studentId, String studentMobileNumber,
			String studentsFatherName, String studentAddress) {
		this.studentName = studentName;
		this.studentEmaiId = studentEmaiId;
		this.studentId = studentId;
		this.studentMobileNumber = studentMobileNumber;
		this.studentsFatherName = studentsFatherName;
		this.studentAddress = studentAddress;
	}
	public String studentName;
	public String studentEmaiId;
	public String studentId;
	public String studentMobileNumber;
	public String studentsFatherName;
	public String studentAddress;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmaiId() {
		return studentEmaiId;
	}

	public void setStudentEmaiId(String studentEmaiId) {
		this.studentEmaiId = studentEmaiId;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentMobileNumber() {
		return studentMobileNumber;
	}

	public void setStudentMobileNumber(String studentMobileNumber) {
		this.studentMobileNumber = studentMobileNumber;
	}

	public String getStudentsFatherName() {
		return studentsFatherName;
	}

	public void setStudentsFatherName(String studentsFatherName) {
		this.studentsFatherName = studentsFatherName;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}

}
