package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.dto.StudentInformation;

public class DataBaseOperation {

	private String studentEmaiId1;

	public boolean insertRecord(StudentInformation std) throws Exception { //METHOD
		String studentName;
		String studentEmaiId;
		String studentId;
		String studentMobileNumber;
		String studentsFatherName;
		String studentAddress;
		
		Connection con = null;
		boolean status = false;
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sproject", "root", "1234");
			Statement stmt = con.createStatement();
			String createTable = "insert into student values('" + std.getStudentName() + "','" + std.getStudentId()
					+ "','" + std.getStudentEmaiId() + "','" + std.getStudentMobileNumber() + "','"
					+ std.getStudentEmaiId() + "','" + std.getStudentAddress() + "')";
			int update = stmt.executeUpdate(createTable);
			System.out.println("update=" + update);
			if (update >= 0) {
				status = true;
				return status;
			}
			// return false;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			con.close();
		}
		return status;
	}

	public boolean updateRecord(String studentId, StudentInformation std) {
		String studentName;
		String studentEmaiId;
		String studentMobileNumber;
		String studentsFatherName;
		String studentAddress;
		
		Connection con = null;
		boolean status = false;
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "root");
			Statement stmt = con.createStatement();
			
			String updateTable = "update student set sname='" + std.getStudentName() + "',semail='"
					+ std.getStudentEmaiId() + "',sid='" + std.getStudentId() + "',smobile='"
					+ std.getStudentMobileNumber() + "',sfather='" + std.getStudentEmaiId() + "',saddress='"
					+ std.getStudentAddress() + "' where sid='" + studentId + "'";
			int update = stmt.executeUpdate(updateTable);
			System.out.println("update=" + update);
			if (update >= 0) {
				status = true;
				return status;
			}
			// return false;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}

	public boolean deleteRecord(String studentId) {
		// JDBC Logic
		// delete from student where id=studentId;
		String studentName;
		String studentEmaiId;
		String studentMobileNumber;
		String studentsFatherName;
		String studentAddress;
		Connection con = null;
		boolean status = false;
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sproject", "root", "root");
			Statement stmt = con.createStatement();
			String deleteRecard = "delete from student where sid='" + studentId + "'";
			int update = stmt.executeUpdate(deleteRecard);
			System.out.println("update=" + update);
			if (update >= 0) {
				status = true;
				return status;
			}
			// return false;

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}

	public void searchRecord(String studentId) {
		String studentName;
		String studentEmaiId;
		String studentMobileNumber;
		String studentsFatherName;
		String studentAddress;
		Connection con = null;
		boolean status = false;
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sproject", "root", "root");
			Statement stmt = con.createStatement();
			String displayRecord = "select * from student where sid='" + studentId + "'";
			ResultSet rs = stmt.executeQuery(displayRecord);
			while (rs.next()) {
				System.out.println("Student Name=" + rs.getString("sname"));
				System.out.println("Student ID=" + rs.getString("sid"));
				System.out.println("Student Email ID=" + rs.getString("semail"));
				System.out.println("Student Mobile Number=" + rs.getString("smobile"));
				System.out.println("Student Father Name=" + rs.getString("sfname"));
				System.out.println("Student Address=" + rs.getString("saddress"));
				System.out.println("---------------------------------------------");
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void displayRecord() {
		String studentName;
		String studentEmaiId;
		String studentMobileNumber;
		String studentsFatherName;
		String studentAddress;
		Connection con = null;
		boolean status = false;
		try {
			// Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sproject", "root", "root");
			Statement stmt = con.createStatement();
			String displayRecord = "select * from student";
			ResultSet rs = stmt.executeQuery(displayRecord);
			while (rs.next()) {
				System.out.println("Student Name=" + rs.getString("sname"));
				System.out.println("Student ID=" + rs.getString("sid"));
				System.out.println("Student Email ID=" + rs.getString("semail"));
				System.out.println("Student Mobile Number=" + rs.getString("smobile"));
				System.out.println("Student Father Name=" + rs.getString("sfname"));
				System.out.println("Student Address=" + rs.getString("saddress"));
				System.out.println("---------------------------------------------");
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
