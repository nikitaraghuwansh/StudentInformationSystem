package com.test;
import com.dao.DataBaseOperation;
import com.dto.StudentInformation;

public class Test {
	
	public static void main(String xyz[]) throws Exception
	{
		DataBaseOperation db=null;
		StudentInformation si=null;
		si=new StudentInformation("sname2","emailid2","sid2","smobileno2","sfname2","saddress2");
		db=new DataBaseOperation();
		//db.insertRecord(si);
		//db.deleteRecord("sid1");
		//db.displayRecord();
		db.searchRecord("sid2");
	}
	}



